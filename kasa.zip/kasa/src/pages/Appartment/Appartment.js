import FirstImage from '../../components/First_image'
import Card from '../../components/Card'
import Footer from '../../components/Footer'

function Appartment() {

  return (
    <div>
      <FirstImage/>
      <Card />
      <Footer/>
    </div>
  )
}
export default Appartment